
// scripts.js - shared utilities (localStorage based)
if(!localStorage.getItem('users')) localStorage.setItem('users', JSON.stringify([]));
if(!localStorage.getItem('invoices')) localStorage.setItem('invoices', JSON.stringify([]));
if(!localStorage.getItem('orders')) localStorage.setItem('orders', JSON.stringify([]));
if(!localStorage.getItem('services')) localStorage.setItem('services', JSON.stringify([]));
if(!localStorage.getItem('settings')) localStorage.setItem('settings', JSON.stringify({bankNobu:'99901000088671',gopay:'085808584252'}));

function saveUser(u){
  const users = JSON.parse(localStorage.getItem('users'));
  users.push(u);
  localStorage.setItem('users', JSON.stringify(users));
}
function findUserByEmail(email){
  return JSON.parse(localStorage.getItem('users')).find(u=>u.email===email);
}
function loginUser(email){
  const u = findUserByEmail(email);
  if(!u) return false;
  localStorage.setItem('clientLogin','true');
  localStorage.setItem('clientID', u.id);
  localStorage.setItem('clientName', u.name);
  localStorage.setItem('clientEmail', u.email);
  return true;
}
function logoutUser(){
  localStorage.removeItem('clientLogin');
  localStorage.removeItem('clientID');
  localStorage.removeItem('clientName');
  localStorage.removeItem('clientEmail');
}
function formatRupiah(n){ return (Number(n)||0).toLocaleString('id-ID'); }

// Admin creds default (change in admin panel)
if(!localStorage.getItem('adminCreds')) localStorage.setItem('adminCreds', JSON.stringify({username:'admin', password:'admin123'}));
function getAdminCreds(){ return JSON.parse(localStorage.getItem('adminCreds')); }
